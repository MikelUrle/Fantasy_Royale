package com.urle;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FantasyRoyaleApplication {

	public static void main(String[] args) {
		SpringApplication.run(FantasyRoyaleApplication.class, args);
	}

}
